--Genere un reporte con los clientes que vinieron m�s de 2 veces el a�o
--pasado

SELECT cod_cliente, ape_cliente+' '+nom_cliente as cliente 
FROM clientes as c
WHERE 2<(SELECT count(*) 
	     FROM facturas as f 
	     WHERE year(fecha) = year(getdate()-1)
	     and c.cod_cliente = f.cod_cliente)

--Listar los datos de las facturas de los clientes que solo vienen a comprar
--en febrero es decir que todas las veces que vienen a comprar haya sido
--en el mes de febrero (y no otro mes)

SELECT nro_factura, cod_cliente, cod_vendedor, fecha
FROM facturas f
WHERE 2=all (SELECT month(fecha) 
		     FROM facturas f1
			 WHERE f.cod_cliente = f1.cod_cliente)

SELECT nro_factura, cod_cliente, cod_vendedor, fecha
FROM facturas f
WHERE not exists (SELECT month(fecha) 
				  FROM facturas f1
				  WHERE f.cod_cliente = f1.cod_cliente
				  and month(fecha)<>2)

--Clientes que no vinieron nunca

SELECT *
FROM clientes
WHERE cod_cliente not in (SELECT cod_cliente 
						  FROM facturas)

SELECT c.cod_cliente, ape_cliente, nro_factura 
FROM clientes c left join facturas f 
	 on c.cod_cliente = f.cod_cliente
WHERE nro_factura is null

--Modificar codigos de clientes
SELECT *
FROM facturas f
WHERE month(fecha) = 2

UPDATE facturas
SET cod_cliente = 15
WHERE nro_factura = 458

--Emitir un listado que muestre n�mero de factura, fecha, art�culo,
--cantidad e importe; para los casos en que la cantidad total de unidades
--vendidas en esa factura sean superior a 80. 

SELECT f.nro_factura, fecha, descripcion, cantidad, cantidad*d.pre_unitario as importe
FROM facturas f join detalle_facturas d on f.nro_factura = d.nro_factura
join articulos a on a.cod_articulo = d.cod_articulo
WHERE 80<(SELECT sum(cantidad)
		  FROM detalle_facturas d1
		  WHERE d1.nro_factura = d.nro_factura)

--Realice un informe que muestre cu�nto fue el total anual facturado por
--cada vendedor, para los casos en que el nombre de vendedor no
--comience con �B� ni con �M�, que los n�meros de facturas oscilen entre 5
--y 25 y que el promedio del monto facturado sea inferior al promedio de
--ese a�o. 

SELECT f.cod_vendedor, sum(cantidad*pre_unitario)
FROM facturas f join vendedores v on v.cod_vendedor=f.cod_vendedor
				join detalle_facturas d on f.nro_factura = d.nro_factura
WHERE nom_vendedor not like '[b,m]%'
	  and d.nro_factura between 5 and 25
GROUP BY f.cod_vendedor, year(fecha)
HAVING avg(cantidad*pre_unitario) < (SELECT avg(cantidad*pre_unitario)
									 FROM facturas f1 join detalle_facturas d1
									 on f1.nro_factura = d1.nro_factura
									 WHERE year(f1.fecha) = year(fecha))

--se quiere listar el precio de los articulos y la diferencia
--de este con el precio del articulo mas caro

SELECT cod_articulo, descripcion, pre_unitario,
				   (SELECT max(pre_unitario) 
				   FROM detalle_facturas d
				   join facturas f on f.nro_factura = d.nro_factura
				   WHERE year(fecha) = year(GETDATE()))-pre_unitario as diferencia,
				   (SELECT max(pre_unitario) FROM articulos) as Articulo_Mas_Caro
FROM articulos

--Se quiere listar el precio de los articulos y 
--el precio al que este fue vendido el a�o pasado

SELECT cod_articulo, descripcion, pre_unitario,
				   (SELECT avg(pre_unitario) 
				   FROM detalle_facturas d join facturas f 
				   on f.nro_factura = d.nro_factura
				   WHERE year(fecha) = year(GETDATE())-1 
				   and a.cod_articulo = d.cod_articulo)	   
FROM articulos a

--Se quiere emitir un listado de las facturas del a�o en curso
--detallando numero de factura, cliente, fecha y total de la misma

SELECT f.nro_factura, fecha, ape_cliente+' '+nom_cliente 'Cliente',f2.Total
FROM facturas f join clientes c on c.cod_cliente = f.cod_cliente
	 join (SELECT nro_factura, SUM(pre_unitario*cantidad) 'Total'
		   FROM detalle_facturas
		   GROUP BY nro_factura)
	 AS f2 on f2.nro_factura = f.nro_factura
WHERE year(fecha) = year(getdate())