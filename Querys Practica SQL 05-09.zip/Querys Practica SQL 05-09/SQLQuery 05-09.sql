--Desde la administracion se solicita un reporte que muestre
--el precio promedio, el importe total y el importe del vendido
--por articulo que no comiencen con "C", que su cantidad total
--vendida sea 100 o mas o que ese importe total vendido
--sea superior a 700

SELECT avg(d.pre_unitario) precio_promedio, 
	   sum(cantidad*d.pre_unitario) Imp_Total,
	   avg(d.pre_unitario*cantidad) importe_promedio,
	   count(*) 'Cantidad Registros',
	   count(distinct nro_factura) 'Cantidad de Nro Facturas',
	   count(distinct a.cod_articulo) 'Cantidad de Articulos'
FROM detalle_facturas d 
	 join articulos a on a.cod_articulo = d.cod_articulo
WHERE descripcion not like 'C%'
GROUP BY a.cod_articulo, descripcion
HAVING sum(cantidad) >= 100 or sum(cantidad*d.pre_unitario) < 700

--El encargado del negocio quiere saber cu�nto fue la facturaci�n del a�o pasado.
--Por otro lado, cu�nto es la facturaci�n del mes pasado, la de este mes y la de hoy
--(Cada pedido en una consulta distinta, y puede unirla en una sola tabla de
--resultado)

SELECT '4' Orden, 'A�o pasado' Periodo, sum(cantidad*pre_unitario) IMPORTE
FROM facturas f join detalle_facturas d on d.nro_factura = f.nro_factura
WHERE year(fecha) = year(getdate())-1
UNION
SELECT '3', 'Mes pasado', sum(cantidad*pre_unitario)
FROM facturas f join detalle_facturas d on d.nro_factura = f.nro_factura
WHERE datediff(month, fecha, getdate()) = 1
UNION
SELECT '2', 'Este mes', sum(cantidad*pre_unitario)
FROM facturas f join detalle_facturas d on d.nro_factura = f.nro_factura
WHERE datediff(month, fecha, getdate()) = 0
UNION
SELECT '1', 'Hoy', sum(cantidad*pre_unitario)
FROM facturas f join detalle_facturas d on d.nro_factura = f.nro_factura
WHERE datediff(day, fecha, getdate()) = 0

--Vistas
--crear una vista que guarde una consulta que liste por cliente
--la cantidad de facturas y montos totales anuales que gasto

CREATE VIEW vis_compra_anual
AS
SELECT cod_cliente, sum(cantidad * pre_unitario) Total,
	   count(distinct d.nro_factura) 'Cantidad de facturas',
	   year(fecha) A�o
FROM facturas f join detalle_facturas d on d.nro_factura = f.nro_factura
GROUP BY cod_cliente, year(fecha)

--Mostrar utilizando la vista anterior los totales comprados
--por clientes cuyo apellido no comience con A y que realizaron
--menos de 2 facturas por a�o

SELECT v.cod_cliente, ape_cliente 'Apellido', Total as 'Total Anual', [Cantidad de facturas], A�o
FROM vis_compra_anual as v join clientes c on c.cod_cliente = v.cod_cliente
WHERE c.ape_cliente not like 'A%' and [Cantidad de facturas] < 2

--Subconsultas en el WHERE
--TEST DE COMPARACION

SELECT cod_articulo, descripcion, pre_unitario
FROM articulos
WHERE pre_unitario<(SELECT avg(pre_unitario) 
					FROM articulos)

--TEST DE PERTENENCIA AL CONJUNTO
--Listar los articulos que se vendieron este a�o

SELECT cod_articulo, descripcion, pre_unitario
FROM articulos
WHERE cod_articulo in (SELECT cod_articulo 
					   FROM detalle_facturas d join facturas f 
					   on d.nro_factura = f.nro_factura
					   WHERE year(fecha) = year(getdate()))

--Listar los articulos que NO se vendieron este a�o

SELECT cod_articulo, descripcion, pre_unitario
FROM articulos
WHERE cod_articulo not in (SELECT cod_articulo 
					       FROM detalle_facturas d join facturas f 
						   on d.nro_factura = f.nro_factura
					       WHERE year(fecha) = year(getdate()))

--TEST DE EXISTENCIA
--Listar los clientes que vinieron este a�o

SELECT c.cod_cliente, ape_cliente, nom_cliente 
FROM clientes c
WHERE exists (SELECT * 
			  FROM facturas  
			  WHERE year(fecha) = year(getdate())
			  and cod_cliente = c.cod_cliente)

--TEST CUANTIFICADOS: ANY - ALL
--Listar los clientes que compraron algun articulo
--con precio mayor a 1000

SELECT * 
FROM clientes c 
WHERE 1000<any(select pre_unitario
				 FROM facturas f join detalle_facturas d 
				 on d.nro_factura = f.nro_factura
				 WHERE c.cod_cliente = cod_cliente)

--Listar los clientes que compraron todos los articulos
--con precios mayores a 1000

SELECT * 
FROM clientes c 
WHERE 1000<all(select pre_unitario
				 FROM facturas f join detalle_facturas d 
				 on d.nro_factura = f.nro_factura
				 WHERE c.cod_cliente = cod_cliente)