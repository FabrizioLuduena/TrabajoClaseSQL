--Cuanto es el monto total facturado por cada vendedor por dia el mes pasado?
--Listar solo aquellos vendedores que hayan hecho 2 o mas
--facturas por dia el mes pasado

SELECT v.cod_vendedor, ape_vendedor, day(fecha) dia, sum(cantidad*pre_unitario) Monto_Total
FROM facturas as f join detalle_facturas as d on d.nro_factura = f.nro_factura 
	 join vendedores as v on v.cod_vendedor = f.cod_vendedor
WHERE datediff(month, fecha, getdate()) = 1
GROUP BY v.cod_vendedor, ape_vendedor, day(fecha)
HAVING count(distinct d.nro_factura)>=2
ORDER BY 1, 3

--Listar los clientes y los vendedores en una misma tabla
--de resultados

SELECT cod_cliente Codigo, 
	   ape_cliente Apellido, 
	   nom_cliente Nombre, 
	   'Cliente' as Tipo
FROM clientes as c 
Union
SELECT cod_vendedor, 
	   ape_vendedor, 
	   nom_vendedor, 
	   'Vendedor' 
FROM vendedores as v
ORDER BY 4, 2, 3

--Listar los montos totales mensuales facturados este a�o
--y al final del listado se quiere ver el monto total facturado este a�o

SELECT 'Mes', month(fecha), sum(cantidad*pre_unitario) Total
FROM facturas as f join detalle_facturas as d on d.nro_factura = f.nro_factura
WHERE year(fecha) = year(getdate())
GROUP BY month(fecha)
UNION
SELECT 'A�o', year(getdate()), sum(cantidad*pre_unitario) Total
FROM facturas as f join detalle_facturas as d on d.nro_factura = f.nro_factura
WHERE year(fecha) = year(getdate())
ORDER BY 1 desc

--Crear una Vista

CREATE VIEW vis_clientes
as
select cod_cliente, ape_cliente + ', ' + nom_cliente as 'Nombre Completo',
calle + ' ' + trim(str(altura)) +' Barrio' + barrio Direccion
from clientes as c join barrios as b on b.cod_barrio = c.cod_barrio

--Consultar la Vista Anterior para clientes cuyo apellido
--comience con letras de a a la m

SELECT * 
FROM vis_clientes
WHERE [Nombre Completo] like '[a-m]%'


